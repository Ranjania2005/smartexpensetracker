package com.example.smartexpensetracker;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SmartexpensetrackerApplicationTests {

	@Test
	void appStarts() {
		assertTrue(true, "Basic application startup check");
	}

}
