package com.example.smartexpensetracker.service;

import com.example.smartexpensetracker.db.DbConnection;
import com.example.smartexpensetracker.model.Expense;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseService {

    public ExpenseService() {
        DbConnection.initDatabase();
    }

    public boolean addExp(Expense expense) {
        String sql = "INSERT INTO expenses (title, amount, category, date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, expense.getTitle());
            stmt.setDouble(2, expense.getAmount());
            stmt.setString(3, expense.getCategory());
            stmt.setDate(4, Date.valueOf(expense.getDate()));
            return stmt.executeUpdate() == 1;
        } catch (SQLException e) {
            System.err.println("Error saving expense: " + e.getMessage());
            return false;
        }
    }

    public List<Expense> showExp() {
        String sql = "SELECT id, title, amount, category, date FROM expenses";
        List<Expense> expenses = new ArrayList<>();

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                expenses.add(mapExpense(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error reading expenses: " + e.getMessage());
        }
        return expenses;
    }

    public List<Expense> searchExpByCategory(String category) {
        String sql = "SELECT id, title, amount, category, date FROM expenses WHERE LOWER(category) LIKE ?";
        List<Expense> expenses = new ArrayList<>();

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + category.toLowerCase() + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    expenses.add(mapExpense(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error searching expenses: " + e.getMessage());
        }
        return expenses;
    }

    public boolean delExp(int id) {
        String sql = "DELETE FROM expenses WHERE id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() == 1;
        } catch (SQLException e) {
            System.err.println("Error deleting expense: " + e.getMessage());
            return false;
        }
    }

    public double calcTotal() {
        String sql = "SELECT SUM(amount) FROM expenses";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total: " + e.getMessage());
        }
        return 0.0;
    }

    public double calcMonthlyTotal(int year, int month) {
        String sql = "SELECT SUM(amount) FROM expenses WHERE YEAR(date) = ? AND MONTH(date) = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, year);
            stmt.setInt(2, month);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error calculating monthly total: " + e.getMessage());
        }
        return 0.0;
    }

    public Map<String, Double> calcCategoryTotals() {
        String sql = "SELECT category, SUM(amount) FROM expenses GROUP BY category";
        Map<String, Double> totals = new HashMap<>();

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                totals.put(rs.getString("category"), rs.getDouble(2));
            }
        } catch (SQLException e) {
            System.err.println("Error calculating category totals: " + e.getMessage());
        }
        return totals;
    }

    public List<Expense> sortExpByAmount(boolean ascending) {
        String order = ascending ? "ASC" : "DESC";
        String sql = "SELECT id, title, amount, category, date FROM expenses ORDER BY amount " + order;
        List<Expense> expenses = new ArrayList<>();

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                expenses.add(mapExpense(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error sorting expenses: " + e.getMessage());
        }
        return expenses;
    }

    public boolean isOverBudget(double limit, int year, int month) {
        return calcMonthlyTotal(year, month) > limit;
    }

    private Expense mapExpense(ResultSet rs) throws SQLException {
        return new Expense(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getDouble("amount"),
                rs.getString("category"),
                rs.getDate("date").toLocalDate()
        );
    }
}
