package com.example.smartexpensetracker;

import com.example.smartexpensetracker.main.ExpenseTrackerApp;

public class SmartexpensetrackerApplication {

	public static void main(String[] args) {
		ExpenseTrackerApp.main(args);
	}

}
