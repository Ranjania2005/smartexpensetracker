package com.example.smartexpensetracker.main;

import com.example.smartexpensetracker.model.Expense;
import com.example.smartexpensetracker.service.ExpenseService;
import com.example.smartexpensetracker.util.InputUtil;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ExpenseTrackerApp {
    private static final double DEFAULT_BUDGET_LIMIT = 1000.0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExpenseService service = new ExpenseService();

        System.out.println("\nSmart Expense Tracker");
        System.out.println("--------------------");
        System.out.println("This simple console app saves expenses to MySQL.");

        while (true) {
            showMenu();
            int choice = InputUtil.readInt(scanner, "Choose an option: ");

            switch (choice) {
                case 1 -> addExpense(scanner, service);
                case 2 -> viewExpenses(service);
                case 3 -> searchByCategory(scanner, service);
                case 4 -> monthlySummary(scanner, service);
                case 5 -> budgetWarning(scanner, service);
                case 6 -> deleteExpense(scanner, service);
                case 7 -> sortExpenses(scanner, service);
                case 8 -> categoryTotals(service);
                case 9 -> loadDatabaseData(service);
                case 10 -> {
                    System.out.println("Exiting system. Goodbye!");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Please choose a valid menu option.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Add expense");
        System.out.println("2. View all expenses");
        System.out.println("3. Search expenses by category");
        System.out.println("4. Monthly expense summary");
        System.out.println("5. Budget limit warning");
        System.out.println("6. Delete expense");
        System.out.println("7. Sort expenses by amount");
        System.out.println("8. Category-wise total");
        System.out.println("9. Retrieve saved data from database");
        System.out.println("10. Exit system");
    }

    private static void addExpense(Scanner scanner, ExpenseService service) {
        String title = InputUtil.readText(scanner, "Enter title: ");
        double amount = InputUtil.readDouble(scanner, "Enter amount: ");
        String category = InputUtil.readText(scanner, "Enter category: ");
        LocalDate date = InputUtil.readDate(scanner, "Enter date");

        Expense expense = new Expense(title, amount, category, date);
        boolean saved = service.addExp(expense);

        if (saved) {
            System.out.println("Expense added successfully.");
            if (service.isOverBudget(DEFAULT_BUDGET_LIMIT, date.getYear(), date.getMonthValue())) {
                System.out.println("Warning: Monthly total exceeds default budget of " + DEFAULT_BUDGET_LIMIT);
            }
        } else {
            System.out.println("Failed to add expense. Please try again.");
        }
    }

    private static void viewExpenses(ExpenseService service) {
        List<Expense> expenses = service.showExp();
        if (expenses.isEmpty()) {
            System.out.println("No expenses found.");
            return;
        }
        System.out.println("\nID | Title              |   Amount | Category     | Date");
        System.out.println("-----------------------------------------------------------");
        expenses.forEach(System.out::println);
        System.out.printf("\nTotal expenses saved: %.2f\n", service.calcTotal());
    }

    private static void searchByCategory(Scanner scanner, ExpenseService service) {
        String category = InputUtil.readText(scanner, "Enter category to search: ");
        List<Expense> results = service.searchExpByCategory(category);
        if (results.isEmpty()) {
            System.out.println("No expenses found for category: " + category);
            return;
        }
        System.out.println("\nSearch results:");
        results.forEach(System.out::println);
    }

    private static void monthlySummary(Scanner scanner, ExpenseService service) {
        int year = InputUtil.readInt(scanner, "Enter year (e.g. 2026): ");
        int month = InputUtil.readInt(scanner, "Enter month (1-12): ");
        double total = service.calcMonthlyTotal(year, month);
        System.out.printf("Total for %d-%02d: %.2f\n", year, month, total);
    }

    private static void budgetWarning(Scanner scanner, ExpenseService service) {
        int year = InputUtil.readInt(scanner, "Enter year (e.g. 2026): ");
        int month = InputUtil.readInt(scanner, "Enter month (1-12): ");
        double limit = InputUtil.readDouble(scanner, "Enter budget limit: ");
        double total = service.calcMonthlyTotal(year, month);
        System.out.printf("Monthly total: %.2f\n", total);
        if (total > limit) {
            System.out.println("Budget warning: Spending is above the entered limit.");
        } else {
            System.out.println("Budget looks stable for this month.");
        }
    }

    private static void deleteExpense(Scanner scanner, ExpenseService service) {
        int id = InputUtil.readInt(scanner, "Enter expense id to delete: ");
        boolean deleted = service.delExp(id);
        if (deleted) {
            System.out.println("Expense deleted successfully.");
        } else {
            System.out.println("Expense id not found.");
        }
    }

    private static void sortExpenses(Scanner scanner, ExpenseService service) {
        System.out.println("Sort order:");
        System.out.println("1. Low to high");
        System.out.println("2. High to low");
        int order = InputUtil.readInt(scanner, "Choose order: ");
        boolean ascending = order != 2;
        List<Expense> sorted = service.sortExpByAmount(ascending);
        if (sorted.isEmpty()) {
            System.out.println("No expenses available to sort.");
            return;
        }
        System.out.println("\nSorted expenses:");
        sorted.forEach(System.out::println);
    }

    private static void categoryTotals(ExpenseService service) {
        Map<String, Double> totals = service.calcCategoryTotals();
        if (totals.isEmpty()) {
            System.out.println("No category totals available.");
            return;
        }
        System.out.println("\nCategory totals:");
        totals.forEach((category, amount) -> System.out.printf("%s: %.2f\n", category, amount));
    }

    private static void loadDatabaseData(ExpenseService service) {
        List<Expense> expenses = service.showExp();
        System.out.println("Loaded " + expenses.size() + " expenses from the database.");
    }
}
